#!/bin/sh
./pipe.sh &
./fstime.sh &
wait