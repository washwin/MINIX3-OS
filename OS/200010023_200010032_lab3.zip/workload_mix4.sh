#!/bin/sh
./spawn.sh &
wait
