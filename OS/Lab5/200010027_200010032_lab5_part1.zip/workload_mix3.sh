#!/bin/sh
./arithoh.sh &
./spawn.sh &
./arithoh.sh &
./spawn.sh &
./arithoh.sh &
wait


