#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ipc.h>

int main(int argc, char* argv[])
{
	if (argc == 1)
	{
		exit(0);	
	}
	
	int num = atoi(argv[argc - 1]);
	int result = 2*num ;
	printf("Twice: Current process id: %u, Current result: %d\n", getpid(), result);
	
	char result_str[20];
	sprintf(result_str, "%d", result);
	
	char* arguments[argc];
	
	for(int i=0; i < argc - 2; i++)
	{
		arguments[i] = argv[i+1];
	}
	
	arguments[argc-2] = result_str;
	arguments[argc-1] = NULL;
	
	execvp(arguments[0], arguments);
	
	return 0;
}
